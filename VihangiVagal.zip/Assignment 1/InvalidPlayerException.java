//importing packages
import java.util.Scanner;
// this class is used to throw exception
public class InvalidPlayerException extends Exception
{
   
    public InvalidPlayerException(String message)
    {
        super(message);
        
    }

   
}
